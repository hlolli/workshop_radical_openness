Quickly create Clojure and ClojureScript repls for a project.
Once the repls are created the usual CIDER commands can be used in either a clj/cljs buffer and the forms will be routed automatically via the correct connection.
So no need to manually switch connections!

Installation:

Available as a package in melpa.org.
M-x package-install clojure-quick-repls
