The long lost Emacs string manipulation library.

See documentation on https://github.com/magnars/s.el#functions
