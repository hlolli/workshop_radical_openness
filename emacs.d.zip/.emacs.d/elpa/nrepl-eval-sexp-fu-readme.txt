Tiny functionality enhancements for evaluating sexps.
This package provides:
- Flashing the sexps during the evaluation.
- `eval-last-sexp' variants (inner-list/inner-sexp).

Installation:

Put the highlight.el to your load-path.
Then require this package.
