To turn on css-eldoc call the function `css-eldoc-enable'
