Bootstrap and Font Awesome

  If  you ok  that  "glyphicon"  classes allowed  only  for <i>  or
"label-default" for  <span>, <label> and  so on, this may  good for
you.   Alternative you  can use  package `ac-html-csswatcher'  that
parse all css in project.

  However  this  package  provide documentation  with  samples  and
additional   data-  attributes   that  `ac-html-csswatcher'   can't
provide, so ac-html-bootstrap may be helpful for you.

Install `ac-html' for `auto-complete' completion framework
or `company-web' if you are using `company' framework.

For  `ac-html' users:  Since ac-html  0.4 is  alpha stage,  and not
stable yet. This package works with  ac-html 0.3 series, if you are
using ac-html 0.4  series, you may downgrade  ac-html aka reinstall
from melpa-stable. `ac-html' 0.4 will be supported in the future.

Usage:

Use `ac-html-bootstrap+' or `company-web-bootstrap+'
and if you want Font Awesome: `ac-html-fa+' or `company-web-fa+'

Note: Font Awesome completion only available for <i> tag

Contribute:

All definition are in bootstrap.yaml
Build script here: https://github.com/osv/h5doc.git
