Add the following to your .emacs file:
(require 'highlight-parentheses)

Enable the mode using M-x highlight-parentheses-mode or by adding it to a
hook.
