Copyright (C) 2012-2016 Tim King, Phil Hagelberg, Bozhidar Batsov, Artur Malabarba and
[contributors](https://github.com/clojure-emacs/cider/contributors).

CIDER is distributed under the GNU General Public License, version 3, the same as Emacs.
Type <kbd>C-h C-c</kbd> in Emacs to view it.

`cider-nrepl` is distributed under the Eclipse Public License, the same as Clojure.
