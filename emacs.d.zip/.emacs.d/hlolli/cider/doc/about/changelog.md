An extensive changelog is available [here](https://github.com/clojure-emacs/cider/blob/master/CHANGELOG.md).
