# Compatibility libraries

Additional libraries for compatibility with older Emacsen:

- `ert.el`:  ERT for Emacs 23
- `package.el`: EPLA for Emacs 23

Load `load.el` to load these libraries if required.
