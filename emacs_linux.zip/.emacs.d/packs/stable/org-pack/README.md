## Org mode pack

This pack includes the latest and greatest version of org-mode.
