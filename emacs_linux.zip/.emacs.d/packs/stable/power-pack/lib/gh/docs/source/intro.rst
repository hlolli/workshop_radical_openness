========
 Basics
========

gh.el is built on top of Eieio. The scope of this client library is to provide
plumbing primitives that will allow full use of the GitHub API.
