Provides a Clojure interactive development environment for Emacs, built on
top of nREPL.

Installation:

Available as a package in melpa.org and stable.melpa.org

(add-to-list 'package-archives
             '("melpa" . "https://melpa.org/packages/"))

or

(add-to-list 'package-archives
             '("melpa-stable" . "https://stable.melpa.org/packages/") t)

M-x package-install cider
