M-x clojars - to search clojars.org for a Clojure library
