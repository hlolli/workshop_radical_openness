Tiny feature adding support for cider eval functions.
See `eval-sexp-fu' help for more info on how to configure the
flash behavior.
