Emacs/W3 is a web browser written entirely in Emacs Lisp.  As such, it has
unique strengths and drawbacks.  The strengths are related to its integration
with Emacs; the drawbacks are that it is relatively slow and sometimes
blocks your editing session.  Development has been dormant for a couple of
years, so expect bugs due to bit rot.
Please report bugs via M-x report-emacs-bug.

This is a very rough pass at the web site (by the original author) just to
get some thoughts down and accessible to more people.  The project page @
Savannah has a fairly detailed task list.  A brief description of each
component and a list of questions and/or resources related to it may be
found in the following documents.
