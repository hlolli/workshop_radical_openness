Provides additional font-locking for clojure-mode.
