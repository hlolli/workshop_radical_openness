//
//  PlayScriptCommand.h
//  MidiScript
//
//  Created by Nicolas Sceaux on 10/09/05.
//  Copyright 2005 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface PlayScriptCommand : NSScriptCommand {
}
- (id) performDefaultImplementation;
@end
